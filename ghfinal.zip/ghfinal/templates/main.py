from flask import Flask, render_template, request
import serial
from serial.serialutil import STOPBITS_ONE, Timeout
import serial.tools.list_ports
import time

app = Flask(__name__)

def connection():
    serialInst = serial.Serial("COM6",9600,parity=serial.PARITY_ODD,stopbits = STOPBITS_ONE)
    return serialInst

def sendInstruction(serialInst,data):
    while not serialInst.isOpen():
        serialInst = connection()
    serialInst.write(data.encode())
    print(data.encode())

@app.route('/')
def index():
    return render_template('control.html')

@app.route('/forward')
def forward():
    forward = request.args.get('forward')
    print(forward)
    serialInst = serial.Serial("COM6",9600,parity=serial.PARITY_ODD,stopbits = STOPBITS_ONE)
    while not serialInst.isOpen():
        serialInst = connection()
    if forward == "w":
        sendInstruction(serialInst,"w")
    return ('nothing')

@app.route('/left')
def left():
    left = request.args.get('left')
    print(left)
    serialInst = serial.Serial("COM6",9600,parity=serial.PARITY_ODD,stopbits = STOPBITS_ONE)
    while not serialInst.isOpen():
        serialInst = connection()
    if left == "a":
        sendInstruction(serialInst,"a")
    return ('nothing')

@app.route('/right')
def right():
    right = request.args.get('right')
    print(right)
    serialInst = serial.Serial("COM6",9600,parity=serial.PARITY_ODD,stopbits = STOPBITS_ONE)
    while not serialInst.isOpen():
        serialInst = connection()
    if right == "d":
        sendInstruction(serialInst,"d")
    return ('nothing')

@app.route('/back')
def back():
    back = request.args.get('back')
    print(back)
    serialInst = serial.Serial("COM6",9600,parity=serial.PARITY_ODD,stopbits = STOPBITS_ONE)
    while not serialInst.isOpen():
        serialInst = connection()
    if back == "s":
        sendInstruction(serialInst,"s")
    return ('nothing')

@app.route('/stop')
def stop():
    stop = request.args.get('stop')
    print(stop)
    serialInst = serial.Serial("COM6",9600,parity=serial.PARITY_ODD,stopbits = STOPBITS_ONE)
    while not serialInst.isOpen():
        serialInst = connection()
    if stop == "x":
        sendInstruction(serialInst,"x")
    return ('nothing')
