<?php 
session_start();

	include("connection.php");
	include("functions.php");

	$user_data = check_login($con);

?>

<!DOCTYPE html>
<html>
<head>
 <?php include 'head1.php' ?>
	<title>My website</title>
</head>
<body style ="background-color: lightblue">
<?php include "nav1.inc.php" ?>

	<h1>Welcome to the challenge, <?php echo $user_data['user_name']; ?>! </h1>


	<br>

</body>
<?php    
  include "footer.inc.php"  
  ?>
</html>