<head>
    <?php include 'head1.php' ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style = "background-color: white"> 
   <?php include 'nav.inc.php' ?>
    <section class="signup-form">      
        <h1>Member Registration</h1>     
        <p>           
            For existing members, please go to the         
            <a href="login.php">Sign In page</a>.       
        </p>      
        <form action="inclusion/register.inc.php" method="post" style="text-align: center;">    
            <input type ="text" name="FirstName" placeholder="First Name...">
            <br><br>
            <input type ="text" name="LastName" placeholder="Last Name...">
            <br><br>
            <input type ="text" name="Username" placeholder="Username...">
            <br><br>
            <input type ="password" name="pwd" placeholder="Password...">
            <br><br>
            <input type ="password" name="pwdrepeat" placeholder="Repeat password...">
            <br><br>
            <button type="submit" name="submit">Sign Up</button>
        </form> 
        <?php
    if (isset($_GET["error"]))
    {
        if($_GET["error"]=="emptyinput")
        {
            echo "<p>Fill in all fields!</p>";
        }
        else if($_GET["error"]=="invaliduid")
        {
            echo "<p>Fill in username!</p>";
        }
        else if($_GET["error"]=="passwordmismatch")
        {
            echo "<p>Passwords do not match!</p>";
        }
        else if($_GET["error"]=="usernametaken")
        {
            echo "<p>Username already exists!</p>";
        }
        else if($_GET["error"]=="stmterror")
        {
            echo "<p>Error, try again!</p>";
        }
        else if($_GET["error"]=="none")
        {
            echo "<p>Successfully Signed Up!</p>";
        }
    }
    ?>
    </section>  
    
  <?php    
  include "footer.inc.php"  
  ?>
</body>


