<?php
session_start();
?>

<link rel="stylesheet" href="csstyle.css">



<nav class="navbar navbar-expand-lg navbar-dark   ">
    <a class="navbar-brand" href="index.php">
        <img src ="pic/next.png"/>
    </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
  
       <ul class ="navbar-nav ml-auto">
       <?php
       if(isset($_SESSION["username"]))
       {
           echo "li class='nav-item'><a class='nav-link'href='profile.php'><i class='fas fa-ice-cream'>Register</i> </a></li>";
           echo " <li class='nav-item ' ><a class='nav-link'href='inclusion/logout.inc.php'><i class='fas fa-coffee'>Login</i> </a></li>";
       }
       else
       {
           echo "li class='nav-item'><a class='nav-link'href='register.php'><i class='fas fa-ice-cream'>Register</i> </a></li>";
           echo " <li class='nav-item ' ><a class='nav-link'href='login.php'><i class='fas fa-coffee'>Login</i> </a></li>";
       }
       ?>
      <li class="nav-item">
          <a class="nav-link"href="register.php">
              <i class="fas fa-ice-cream">Register</i> </a>
      </li>
       <li class="nav-item " >
          <a class="nav-link"href="login.php">
              <i class="fas fa-coffee">Login</i> </a>
      </li>
       
    </ul>
  </div>
</nav>