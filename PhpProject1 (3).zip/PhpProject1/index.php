<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        
        <!--jQuery-->
        
        <script defer 
        src="https://code.jquery.com/jquery-3.4.1.min.js"  
        integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="    
        crossorigin="anonymous">
        </script>
        <!--Bootstrap JS--> 
        <script defer    
                src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"    
                integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm"    
                crossorigin="anonymous">
                    
        </script>
        <script src='https://kit.fontawesome.com/a076d05399.js'></script>
        <link rel="stylesheet"
              href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"    
              integrity=        "sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
              crossorigin="anonymous">
        <link rel="stylesheet" href="csstyle.css">

             
        <script defer src ="lightup.js"></script>
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
        <title>2201</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body style = "background-color: white">
        <?php include "nav.inc.php" ?>
       
        <header class = "jumbotron text-center jumbotron-fluid" style ="background-image: url('projimg/chocake.jpg');">
            <div class ="container-banner">
                <h1 class ="display-1"><em>2201</em></h1>
            </div>
        </header>
        <?php
       if(isset($_SESSION["username"]))
       {
           echo "<p>Hello " . $_SESSION["username"]. "</p>";
       }
       ?>
    </body>
    
      <?php    
  include "footer.inc.php"  
  ?>
</html>
