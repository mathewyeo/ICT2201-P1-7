<?php
if (isset($_POST["submit"]))
{
    $username = $_POST["username"];
    $pwd = $_POST["pwd"];
    
    require_once 'db.inc.php';
    require_once 'functions.inc.php';
    
     if(emptyInputLogin($username,$pwd) !== false)
    {
        header("location: ../login.php?error=emptyinput");
        exit();
    }
    loginUser($conn,$username,$pwd);
}
else
{
    header("location: ../login.php?error=emptyinput");
    exit();
}
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

