<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<?php
if (isset($_POST["submit"]))
{
    $fname = $_POST["FirstName"];
    $lname = $_POST["LastName"];
    $username = $_POST["Username"];
    $pwd = $_POST["pwd"];
    $pwdRepeat = $_POST["pwdrepeat"];
    define('CWD', getcwd());
    require CWD .'/db.inc.php';
    require CWD .'/functions.inc.php';
    
    if(emptyInputSignup($fname,$lname,$username,$pwd,$pwdRepeat ) !== false)
    {
        header("location: ../register.php?error=emptyinput");
        exit();
    }
    
    if(invalidUser($username) !== false)
    {
        header("location: ../register.php?error=invaliduid");
        exit();
    }
    
     if(pwdMatch($pwd,$pwdRepeat) !== false)
    {
        header("location: ../register.php?error=passwordmismatch");
        exit();
    }
    
    if(uidExists($conn,$username ) !== false)
    {
        header("location: ../register.php?error=usernametaken");
        exit();
    }
    
    createUser($conn,$fname,$lname,$username,$pwd);
}
else
{
    header("location: ../register.php");
    exit();
}