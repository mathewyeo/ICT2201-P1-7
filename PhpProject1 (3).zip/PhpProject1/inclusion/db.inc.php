<?php
$serverName = "localhost";
$dBUsername = "root";
$dBPassword = "";
$dBName = "2201site";

$conn = mysqli_connect($serverName,$dBUsername,$dBPassword,$dBName);
if(!$conn)
    {
    die("Connection refused: " . mysqli_connect_error());
}

