<?php


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function emptyInputSignup($fname,$lname,$username,$pwd,$pwdRepeat)
{
    $results;
    if (empty($fname)|| empty($lname) || empty($username)|| empty($pwd)|| empty($pwdRepeat))
    {
        $results = true;
    }
    else
    {
        $results = false;
    }
    return $results;
}

function invalidUser($fname,$lname,$username,$pwd,$pwdRepeat)
{
    $results;
    if (!preg_match("/^[a-zA-Z0-9]*$/" , $username))
    {
        $results = true;
    }
    else
    {
        $results = false;
    }
    return $results;
}

function pwdMatch($pwd,$pwdRepeat)
{
    $results;
    if ($pwd !== $pwdRepeat)
    {
        $results = true;
    }
    else
    {
        $results = false;
    }
    return $results;
}

function uidExists($conn,$username)
{
    $sqls = "SELECT * FROM users  WHERE userName = ?;";
    $stmts = mysqli_stmt_init($conn);
    if (mysqli_stmt_prepare($stmts, $sqls))
    {
         header("location: ../register.php?error=stmterror");
        exit();
    }
    mysqli_stmt_bind_param($stmts, "s", $username);
    mysqli_stmt_execute($stmts);
    $resultData = mysqli_stmt_get_result($stmts);
    if ($rows = mysqli_fetch_assoc($resultData))
    {
        return $rows;
    }
    else 
    {
        $results = false;
        return $results;
    }
    mysqli_stmt_close($stmts);
}

function createUser($conn,$fname,$lname,$username,$pwd)
{
    $sqls = "INSERT INTO users ($usersfName,$userslName,$userName,$usersPwd) VALUES (?,?,?,?);";
    $stmts = mysqli_stmt_init($conn);
    if (mysqli_stmt_prepare($stmts, $sqls))
    {
        header("location: ../register.php?error=stmterror");
        exit();
    }
    
    $hashPwd = password_hash($pwd, PASSWORD_DEFAULT);
    mysqli_stmt_bind_param($stmts, "ssss", $fname,$lname,$username,$hashPwd);
    mysqli_stmt_execute($stmts);
    mysqli_stmt_close($stmts);
    header("location: ../index.php?error=none");
    exit();
    
}

function emptyInputLogin($username,$pwd)
{
    $results;
    if (empty($username)|| empty($pwd))
    {
        $results = true;
    }
    else
    {
        $results = false;
    }
    return $results;
}

function loginUser($conn, $username, $pwd)
{
    $uidExists = uidExists($conn,$username);
    if ($uidExists === false)
    {
        header("location: ../login.php?error=loginfail");
        exit();
    
    }
    
    $pwdHash = $uidExists["usersPwd"];
    $checkPwd = password_verify($pwd, $pwdHashed);
    if ($checkPwd === false)
    {
        header("location: ../login.php?error=loginfail");
        exit();
    }
    else if ($checkPwd === true)
    {
        session_start();
        $_SESSION["usersid"] = $uidExists["usersId"];
        $_SESSION["username"] = $uidExists["userName"];
        header("location: ../index.php?");
        exit();
    }
}