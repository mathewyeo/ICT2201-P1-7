<head>
    <?php include 'head1.php' ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style = "background-color: white"> 
   <?php include 'nav.inc.php' ?>
    <main class="container">      
        <h1>Member Login</h1>     
        <p>           
            For existing members, please go to the         
            <a href="register.php">Sign Up page</a>.       
        </p>      
        <form action ="inclusion/login.inc.php" method="post">      
            
             <div class ='form-group'>          
                <label for="username">Username:</label>    
            <input class ='form-control' name = "username" type="username" id="username" required name="username"        
                   placeholder="Enter username">         
             </div>
            
             <div class ='form-group'>                
                <label for="pwd">Password:</label>  
            <input class ='form-control' name = "pwd "type="pwd" id="pwd" required name="pwd"            
                   placeholder="Enter password">    
    
             </div>
             
            <select name="cars" id="cars">
              <option value="pos">--Select Position--</option>
              <option value="Admin">Administrator</option>
              <option value="Student">Student</option>
              
            </select>
            <br><br>
           
             <div class ='form-group'>   
                 <a href ="index.php">
                 <button class ='btn btn-primary' type="submit">Submit</button> 
                 </a>
             </div>
        </form>  
          <?php
    if (isset($_GET["error"]))
    {
        if($_GET["error"]=="emptyinput")
        {
            echo "<p>Fill in all fields!</p>";
        }
        else if($_GET["error"]=="loginfail")
        {
            echo "<p>Login Failed!</p>";
        }       
    }
    ?>
    </main>  
      <?php    
  include "footer.inc.php"  
  ?>
</body>
